self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "96e018c664efa8b2850c9bfc375216e9",
    "url": "/index.html"
  },
  {
    "revision": "2aab87e6e3193ab66561",
    "url": "/static/css/2.f7da340e.chunk.css"
  },
  {
    "revision": "e56fb4d455fb585a7fdf",
    "url": "/static/css/main.2c90aa8d.chunk.css"
  },
  {
    "revision": "2aab87e6e3193ab66561",
    "url": "/static/js/2.0fdc5a49.chunk.js"
  },
  {
    "revision": "0e8a0264058a038ec5cbdd806f84e5c5",
    "url": "/static/js/2.0fdc5a49.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e56fb4d455fb585a7fdf",
    "url": "/static/js/main.1e667227.chunk.js"
  },
  {
    "revision": "60949e83de0aeb529ab1",
    "url": "/static/js/runtime-main.25c7e1d9.js"
  },
  {
    "revision": "39ab59954fa3a4e1f7284abf26e50e18",
    "url": "/static/media/1.39ab5995.png"
  },
  {
    "revision": "27c4abf8310ce0b4fe7d41c3fc60b13b",
    "url": "/static/media/2.27c4abf8.png"
  },
  {
    "revision": "89ed9f62011950fadcb65792092eb681",
    "url": "/static/media/3.89ed9f62.png"
  },
  {
    "revision": "333cc59068d402da65f812c8bdfea2b8",
    "url": "/static/media/4.333cc590.png"
  },
  {
    "revision": "6a1afa61d91de873b537d2953a02c049",
    "url": "/static/media/5.6a1afa61.png"
  },
  {
    "revision": "c66d69fda362684fe30cee0e3b5c50cd",
    "url": "/static/media/6.c66d69fd.png"
  },
  {
    "revision": "8b165f8e91385349006b03361305d906",
    "url": "/static/media/7.8b165f8e.png"
  },
  {
    "revision": "33e789f521a554b419aa67deecde30b7",
    "url": "/static/media/AVINASH.33e789f5.jpg"
  },
  {
    "revision": "a19d79b9035ac9e969240c2cb96ee558",
    "url": "/static/media/Aakash Kumar Singh.a19d79b9.jpg"
  },
  {
    "revision": "af81c67b75c925ac76f25e5a7fed8ef1",
    "url": "/static/media/Aashisha Singh.af81c67b.jpg"
  },
  {
    "revision": "89808ba5409224b4e062ce90c48fd627",
    "url": "/static/media/Abhishek Raj.89808ba5.jpg"
  },
  {
    "revision": "2cd04819481584bdc9cd5d4b3afeb630",
    "url": "/static/media/Akshat Tripathi.2cd04819.jpg"
  },
  {
    "revision": "ec3c1424dd45b48e1dd850dc9364c60b",
    "url": "/static/media/Dhyey Mistry.ec3c1424.jpg"
  },
  {
    "revision": "268e436d6c06f33c21ffaa3dec7ea671",
    "url": "/static/media/Hirdesh Gupta.268e436d.jpg"
  },
  {
    "revision": "d4a3cdbdb870b395eba3a8e5adc85d82",
    "url": "/static/media/Ishan Thapa.d4a3cdbd.jpg"
  },
  {
    "revision": "47bac463439b7aef3bbac8fe4267215a",
    "url": "/static/media/Madhav Agarwal.47bac463.jpg"
  },
  {
    "revision": "3accea5d66c9ab49edec848e89a8316d",
    "url": "/static/media/Madhulika Mohanty.3accea5d.jpg"
  },
  {
    "revision": "fb2401def9decb162edd38413dc8be62",
    "url": "/static/media/Prince Kumar.fb2401de.jpg"
  },
  {
    "revision": "913848065dc23c36964d47b3f2f8b87c",
    "url": "/static/media/Rajendra  Pamula.91384806.jpg"
  },
  {
    "revision": "e057073cc38dd858f38fbb21833e9920",
    "url": "/static/media/Rashmikiran Pandit.e057073c.jpg"
  },
  {
    "revision": "e9bcdfc398cc44a272cd965c89e4edb4",
    "url": "/static/media/Sahil Siyag.e9bcdfc3.jpg"
  },
  {
    "revision": "ebc4f50672e05501a4a4b86215e4f3cc",
    "url": "/static/media/Sameer Jain.ebc4f506.jpg"
  },
  {
    "revision": "0d6bc31a2dd37442569e8ef3403ddc8b",
    "url": "/static/media/Satyavart.0d6bc31a.jpg"
  },
  {
    "revision": "fbf895e2acf0a4c7b8ab19446651f56b",
    "url": "/static/media/Saurabh Raj.fbf895e2.jpg"
  },
  {
    "revision": "80187212faa7206ca70a750f92d4b2b3",
    "url": "/static/media/Shubhagyata Swaraj Jayswal.80187212.jpg"
  },
  {
    "revision": "20497c5e9a3a752040abe424397262b8",
    "url": "/static/media/Swapnil Narayan.20497c5e.jpg"
  },
  {
    "revision": "272e9123e5cf533a9eb87edf27551994",
    "url": "/static/media/Yash Vardhan.272e9123.jpg"
  },
  {
    "revision": "d004fbc027c8a4ab48d0d8c347ea41fb",
    "url": "/static/media/abc.d004fbc0.jpg"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "d7afdccd19ba8de00db08e5fda5695dc",
    "url": "/static/media/benefits-01.d7afdccd.png"
  },
  {
    "revision": "c129936342156f51d5441bb84bfb51ea",
    "url": "/static/media/benefits-02.c1299363.jpg"
  },
  {
    "revision": "beb5c819fef81dd231bf4177747c03a2",
    "url": "/static/media/clg-logo.beb5c819.jpg"
  },
  {
    "revision": "799e3de2e629ffe3d2807a831fa9c787",
    "url": "/static/media/codechef.799e3de2.png"
  },
  {
    "revision": "221c17b70bd0c071cdab4949f74f65ec",
    "url": "/static/media/codingblocks.221c17b7.png"
  },
  {
    "revision": "64b3323984c943832daecdecd5dbd8af",
    "url": "/static/media/codingninjas.64b33239.png"
  },
  {
    "revision": "64ba66dbf992be12b434f88061ea514c",
    "url": "/static/media/cse-dept.64ba66db.jpeg"
  },
  {
    "revision": "69c56c4e0a1cf5a0a3cff4b943c1cd71",
    "url": "/static/media/devfolio.69c56c4e.png"
  },
  {
    "revision": "e1782ae4a2336dce61e3f5d55d31634c",
    "url": "/static/media/flip.e1782ae4.webp"
  },
  {
    "revision": "2db5da9eec36a2bd7e9281d523db983e",
    "url": "/static/media/foxmula.2db5da9e.png"
  },
  {
    "revision": "615c9198f8e78299bb8944afbf39d86a",
    "url": "/static/media/geeksforgeeks.615c9198.png"
  },
  {
    "revision": "94f90a8a6a8302fa3ea7b99c4fe86b91",
    "url": "/static/media/github.94f90a8a.png"
  },
  {
    "revision": "e0590e5a0a39a2ed8e7c962bc6b7592b",
    "url": "/static/media/gsoc.e0590e5a.png"
  },
  {
    "revision": "99cacd9d1e720b1520707d87d85ee80d",
    "url": "/static/media/icpc.99cacd9d.png"
  },
  {
    "revision": "cde7daf2297b38128f4032d05efef7d4",
    "url": "/static/media/logo.cde7daf2.jpg"
  },
  {
    "revision": "0e20ae930cec8213b410b71103b164c1",
    "url": "/static/media/mail.0e20ae93.gif"
  },
  {
    "revision": "39a9ff93933eb16a63375d94f0945915",
    "url": "/static/media/skillenzatransparent.39a9ff93.png"
  },
  {
    "revision": "89c7a8b114658e82ca46f4ef6eeae823",
    "url": "/static/media/techgig.89c7a8b1.png"
  },
  {
    "revision": "e042a766da20b85c3dd359ece73ecdc8",
    "url": "/static/media/utube.e042a766.png"
  },
  {
    "revision": "11d12a8a5c936e88b110e26ba5021238",
    "url": "/static/media/vid.11d12a8a.mp4"
  }
]);